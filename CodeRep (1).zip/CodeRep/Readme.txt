1.Run the application
2. Login -
there are 2 users 
	CoAuthor-abc@gmail.com,Abc@1234 and Main Author - asd@gmail.com,Asd@1234
3.Use upload form to upload project. There are 2 projects already uploaded.
4.Click on add user to add co developers.
5.Click on Download to downloadthe zip file.
6.Click on project name to navigate through project folders.
7.click on any file to open it in new window.
8. Make changes and check in file it will show who checked in and when. You can also see previous versions and next version.
9.Click Search to search repository for the projects the user has access to and also the ones he is codeveloping.
10.Login as CoAuthor and see he has access to the same project. 
11.Follow same steps for the CoAuthor.
12.You can register new user and also do the same checks.