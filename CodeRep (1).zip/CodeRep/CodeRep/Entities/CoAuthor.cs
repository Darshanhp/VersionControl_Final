﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeRep.Entities
{
    public class CoAuthor
    {
        public int ID { get; set; }
        public string Project { get; set; }
        public string Author { get; set; }
        public string CoAuhtor { get; set; }
    }
}
